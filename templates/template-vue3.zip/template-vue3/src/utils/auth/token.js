export function getToken() {}

export function setToken(token) {}

export function removeToken() {}
