export const formLabelStyle = {
  display: "inline-flex",
  alignItems: "center",
}

export const formItemContentDescStyle = {
  color: "#999",
}

export default {}
