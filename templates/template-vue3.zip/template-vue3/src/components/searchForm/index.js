import PdSearchForm from "./src/SearchForm.vue"

PdSearchForm.install = (app) => {
  app.component(PdSearchForm.name, PdSearchForm)
}

export default PdSearchForm
