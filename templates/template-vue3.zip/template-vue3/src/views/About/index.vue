<template>
  <div>
    <h2>About Page</h2>
  </div>
</template>

<script>
  import { ref, onMounted } from 'vue';
  export default {
    name: 'AboutPage',
  };
</script>
<script setup></script>

<style scoped lang="scss"></style>
