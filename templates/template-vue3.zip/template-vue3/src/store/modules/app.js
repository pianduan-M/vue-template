import { defineStore } from 'pinia';
import { lStorage } from '@/utils/storage';

export const useAppStore = defineStore({
  id: 'app',
  state: () => ({}),
  actions: {},
});
