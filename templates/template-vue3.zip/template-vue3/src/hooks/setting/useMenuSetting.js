// import { useAppStore } from '@/store';

export function useMenuSetting() {
  // const app = useAppStore();
}
