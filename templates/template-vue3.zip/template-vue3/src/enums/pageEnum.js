export const PageEnum = {
  // basic home path
  BASE_HOME: '/home',
};
